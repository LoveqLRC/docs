package com.example.administrator.calendardemo;

import com.example.administrator.calendardemo.utils.CalendarUtil;

import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static org.junit.Assert.assertEquals;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }

    @Test
    public void test() {
        int weekOfYear = CalendarUtil.getWeekOfYear(2017, 1, 1);
        System.out.println(weekOfYear);

    }

    @Test
    public void test2() throws ParseException {
//        List<CalendarBean> weekOfDayList = CalendarUtil.getWeekOfDayList(2017, 4, 16);
//        for (CalendarBean bean : weekOfDayList) {
//            System.out.println(bean);
//        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        String strBefore = "2016-12-24";
        String strBefore = "2017-01-15";
        String strAfter = "2017-01-01";
        Calendar before = Calendar.getInstance();
        Calendar after = Calendar.getInstance();
        before.setTime(sdf.parse(strBefore));
        after.setTime(sdf.parse(strAfter));
        int week = before.get(Calendar.DAY_OF_WEEK);
        before.add(Calendar.DATE, -week);
        week = after.get(Calendar.DAY_OF_WEEK);
        after.add(Calendar.DATE, 7 - week);
        int interval = (int) ((after.getTimeInMillis() - before
                .getTimeInMillis()) / (3600 * 1000 * 24 * 7));
        interval = interval - 1;
        System.out.println(interval);
    }


    @Test
    public void interval() {
//        int weekInterval = CalendarUtil.getWeekInterval(2017, 4, 15);
//        System.out.println(weekInterval);


//        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
//        String format = sdf.format(new Date());
//        String[] split = format.split("-");
//        for (String s : split) {
//            System.out.println(s);
//        }
//        System.out.println(format);

//
//        Calendar instance = Calendar.getInstance();
//        instance.set(2017,4,18);
//        System.out.println(instance.getTimeInMillis());

//        Calendar c1 = Calendar.getInstance();
//        c1.set(2017,4,18);
//        Date d1 = c1.getTime();
//
//        Calendar c2=Calendar.getInstance();
//        c2.set(2017,4,15);
//
//        Date d2 = c2.getTime();
//
//        System.out.println(c2.after(c1));
//
//        long n1 = d1.getTime();
//        long n2 = d2.getTime();
//        long diff = Math.abs(n1 - n2);
//        diff /= 3600 * 1000 * 24;
//        if(diff % 7 != 0){
//            System.out.println((int) (diff / 7 + 1));
//        }
//        System.out.println((int) (diff / 7));



        int interval = CalendarUtil.getWeekInterval(2017, 4, 30);
        System.out.println(interval);
    }

}