package com.example.administrator.calendardemo;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import com.example.administrator.calendardemo.adapter.MonthPagerAdapter;
import com.example.administrator.calendardemo.adapter.WeekPagerAdapter;
import com.example.administrator.calendardemo.demo.MonthEvent;
import com.example.administrator.calendardemo.demo.MonthJumpEvent;
import com.example.administrator.calendardemo.demo.MyAdapter;
import com.example.administrator.calendardemo.demo.WeekEvent;
import com.example.administrator.calendardemo.ui.CalendarViewPager;
import com.example.administrator.calendardemo.ui.MonthView;
import com.example.administrator.calendardemo.ui.WeekView;
import com.example.administrator.calendardemo.utils.CalendarUtil;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.vp_week)
    CalendarViewPager vp_week;

    @BindView(R.id.vp_month)
    CalendarViewPager vp_month;

    @BindView(R.id.list)
    RecyclerView mList;

    //    @BindView(R.id.myvp)
//    ViewPager mVp;
//
//    @BindView(R.id.toggle)
//    Button mToggle;

    private WeekPagerAdapter mWeekAdapter;
    private MonthPagerAdapter mMonthAdapter;
    private MonthJumpEvent monthJumpEvent;
    private int[] mYmd;
    private WeekEvent weekEvent;
    private int currentMonth;
    private MonthEvent monthEvent;
    private boolean mIsMonthChange;
    private int mWeek;

    //
//    @BindView(R.id.vp)
//    CalendarViewPager mVp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        mYmd = CalendarUtil.getYMD(new Date());
        currentMonth = mYmd[1];
        mMonthAdapter = new MonthPagerAdapter(vp_month);
        vp_month.setAdapter(mMonthAdapter);
//        vp_month.setCurrentItem(Integer.MAX_VALUE / 2, false);
        vp_month.setCurrentItem(mMonthAdapter.getCount() / 2, false);

        mWeekAdapter = new WeekPagerAdapter();
        vp_week.setAdapter(mWeekAdapter);
        vp_week.setCurrentItem(mWeekAdapter.getCount()/ 2, false);


        mList.setLayoutManager(new LinearLayoutManager(this));
        mList.setAdapter(new MyAdapter());

        vp_month.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                MonthView monthView = (MonthView) vp_month.findViewById(position);
                if (vp_week.getVisibility() == View.INVISIBLE) {

                    if (monthJumpEvent != null) {//按当月的其他日
                        monthView.updateSelectPoiAfterJump(monthJumpEvent);//更新下一页的选中位置
                        monthJumpEvent = null;//必须是按当月的其他日，才允许跳转
                    }


                    //当移动一页后，vp_week根据最新的页的位置进行跳转
//                    int lastSelectPosition = monthView.mLastSelectPosition;
//                    int interval = monthView.getWeekInterval();
//                    mWeekAdapter.updateWeekInterval(interval, (lastSelectPosition + 1) % 7);

//                    mIsMonthChange = true;
                    int lastSelectPosition = monthView.mLastSelectPosition;
                    int interval = monthView.getWeekInterval();
                    mWeek = (lastSelectPosition + 1) % 7==0?7:(lastSelectPosition + 1) % 7;
//                    mWeekAdapter.updateWeekInterval(interval, (lastSelectPosition + 1) % 7);
                    vp_week.setCurrentItem(mWeekAdapter.getCount()/2-interval);
                    WeekView weekView = (WeekView) vp_week.findViewById(vp_week.getCurrentItem());
                    Log.d("MainActivity", "weekView.mLastSelectPosition:" + weekView.mLastSelectPosition);
                    Log.d("MainActivity", "mWeek:" + mWeek);
                    weekView.updateStateById(mWeek-1);

                } else {
                    if (weekEvent != null) {
                        monthView.updateSelectPoiAfterJump(weekEvent);
                        weekEvent = null;
                    }
                }

            }
        });

//        vp_week.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
//            @Override
//            public void onPageSelected(int position) {
//                super.onPageSelected(position);
//                if (vp_week.getVisibility() == View.VISIBLE) {
//                    WeekView weekView = (WeekView) vp_week.findViewById(position);
//                    CalendarBean lastSelectDate = weekView.getLastSelectDate();
//                    Log.d("MainActivity", "lastSelectDate.year:" + lastSelectDate.year);
//                    Log.d("MainActivity", "lastSelectDate.moth:" + lastSelectDate.moth);
//                    Log.d("MainActivity", "lastSelectDate.day:" + lastSelectDate.day);
//
//                    MonthView monthView = (MonthView) vp_month.findViewById(vp_month.getCurrentItem());
//
//                    int i = monthView.dayInMonth(lastSelectDate);
//                    if (i != 0) {
//                        vp_month.setCurrentItem(vp_month.getCurrentItem() + i);
//                        MonthView newMonth = (MonthView) vp_month.findViewById(vp_month.getCurrentItem());
//                        newMonth.updateSelectPoiAfterJump(lastSelectDate);
//                    }else{
//                        monthView.updateSelectPoiAfterJump(lastSelectDate);
//                    }
//
//
//                }
//
//            }
//        });

//        vp_week.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener(){
//            @Override
//            public void onPageSelected(int position) {
//                super.onPageSelected(position);
////                if (mIsMonthChange){
////                    WeekView weekView = (WeekView) vp_week.findViewById(position);
////                    weekView.updateStateById(mWeek-1);
////                    mIsMonthChange=false;
////                }
//            }
//        });

    }


    @Override
    protected void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    /**
     * 点击WeekView Item的回调
     * 如果点击的是同一个item，不会回调
     *
     * @param event
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onWeekEvent(WeekEvent event) {
        int monthInterval = event.month - currentMonth;
        this.weekEvent = event;
        if (monthInterval == 0) {
            MonthView monthView = (MonthView) vp_month.findViewById(vp_month.getCurrentItem());
            monthView.updateSelectPoiAfterJump(event);
        } else {
            int item = vp_month.getCurrentItem() + monthInterval;
            Log.d("MainActivity", "monthInterval:" + monthInterval);
            vp_month.setCurrentItem(item);
        }
        currentMonth = event.month;
    }

//    @Subscribe(threadMode = ThreadMode.MAIN)
//    public void onMsgEvent(MessageEvent event) {
////        Log.d("MainActivity", event.getMsg());
//        mMonthAdapter.updateMonthInterval(1, 3);
//    }


    /**
     * 点击MonthView Item的回调(只有点击的是本月的才会回调)
     * 如果点击的是同一个item，不会回调
     *
     * @param event
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMonthEvent(MonthEvent event) {
        this.monthEvent=event;
        int weekInterval = CalendarUtil.getWeekInterval(event.year, event.month, event.day);
        Log.d("MainActivity", "weekInterval:" + weekInterval);
//        mWeekAdapter.mLastSelectPosition=event.week;
        vp_week.setCurrentItem(mWeekAdapter.getCount()/2-weekInterval);
        WeekView weekView = (WeekView) vp_week.findViewById(vp_week.getCurrentItem());
        weekView.updateStateById(monthEvent.week-1);
//        mWeekAdapter.updateWeekInterval(weekInterval, event.week);
    }


    /**
     * 点击MonthView Item的回调(只有点击的是在本月显示的其他日期才会回调)
     *
     * @param event
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMonthJumpEvent(MonthJumpEvent event) {

        this.monthJumpEvent = event;
        if (event.upOrNext == 1) {//跳到下一页
            vp_month.setCurrentItem(vp_month.getCurrentItem() + 1, false);
        } else {
            vp_month.setCurrentItem(vp_month.getCurrentItem() - 1, false);
        }
    }


//    @OnClick(R.id.toggle)
//    public void onViewClicked() {
//        Toast.makeText(this, "更新", Toast.LENGTH_SHORT).show();
//
//    }
}
