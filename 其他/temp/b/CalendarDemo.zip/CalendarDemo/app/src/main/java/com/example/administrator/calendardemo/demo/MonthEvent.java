package com.example.administrator.calendardemo.demo;

/**
 * Created by liaoruochen on 2017/4/18.
 * Description:
 */

public class MonthEvent {
    public int year;
    public int month;
    public int day;
    public int week;

    public MonthEvent(int year, int month, int day,int week) {
        this.year = year;
        this.month = month;
        this.day = day;
        this.week=week;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }
}
