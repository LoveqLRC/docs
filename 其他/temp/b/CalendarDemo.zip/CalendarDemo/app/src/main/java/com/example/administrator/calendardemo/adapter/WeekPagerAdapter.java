package com.example.administrator.calendardemo.adapter;

import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import com.example.administrator.calendardemo.entity.CalendarBean;
import com.example.administrator.calendardemo.ui.WeekView;
import com.example.administrator.calendardemo.ui.imp.CalendarViewTop;
import com.example.administrator.calendardemo.utils.CalendarUtil;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by liaoruochen on 2017/4/12.
 * Description:
 */

public class WeekPagerAdapter extends PagerAdapter implements CalendarViewTop {

    public int mLastSelectPosition = 1;
    LinkedList<WeekView> cache = new LinkedList<>();
    int interval=0;

    public WeekPagerAdapter() {

        int[] sevenDay = CalendarUtil.getSevenDay(0);
        mLastSelectPosition = CalendarUtil.getDayOfWeek(sevenDay[0], sevenDay[1], sevenDay[2]);
    }

    @Override
    public int getCount() {

//        return Integer.MAX_VALUE;
        return 1200;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        WeekView view;
        if (!cache.isEmpty()) {
            view = cache.removeFirst();
        } else {
            view = new WeekView(container.getContext());
        }
        Log.d("WeekPagerAdapter", "刷新啦  position"+position);
        view.setId(position);
//        int[] sevenDay = CalendarUtil.getSevenDay(-position + Integer.MAX_VALUE / 2+interval);
        int[] sevenDay = CalendarUtil.getSevenDay(-position + getCount() / 2+interval);
        List<CalendarBean> weekOfDayList = CalendarUtil.getWeekOfDayList(sevenDay[0], sevenDay[1], sevenDay[2]);
        view.updateData(weekOfDayList, mLastSelectPosition - 1);
        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
        cache.addLast((WeekView) object);
    }

    /**
     * 使   notifyDataSetChanged();生效
     * @param object
     * @return
     */
    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE ;
    }

    @Override
    public int[] getCurrentSelectPosition() {
        return new int[0];
    }


    public void updateWeekInterval(int interval, int dayOfWeek){
        this.interval=interval;
        Log.d("jump", "updateWeekInterval :dayOfWeek:" + dayOfWeek);
        mLastSelectPosition=dayOfWeek==0?7:dayOfWeek;//dayOfWeek==0用于判断vp_month的onPageSelect回调方法
        Log.d("jump", "updateWeekInterval :mLastSelectPosition:" + mLastSelectPosition);
        notifyDataSetChanged();
    }
}
