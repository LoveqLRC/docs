package com.example.administrator.calendardemo.dep;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;

/**
 * Created by liaoruochen on 2017/4/13.
 * Description:
 */

public class DemoViewPager extends ViewPager {

    public DemoViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
