package com.example.administrator.calendardemo.widget;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/**
 * Created by liaoruochen on 2017/4/14.
 * Description:
 */

public class CalendarTestLayout extends FrameLayout {

    public CalendarTestLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
}
