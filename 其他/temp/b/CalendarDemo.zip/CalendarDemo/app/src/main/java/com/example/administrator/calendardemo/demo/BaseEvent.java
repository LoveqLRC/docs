package com.example.administrator.calendardemo.demo;

/**
 * Created by liaoruochen on 2017/4/19.
 * Description:
 */

public class BaseEvent {
    public int year;
    public int month;
    public int day;

}
