package com.example.administrator.calendardemo.ui;

import android.content.Context;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.VelocityTrackerCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.ScrollerCompat;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;

import com.example.administrator.calendardemo.demo.MessageEvent;

import org.greenrobot.eventbus.EventBus;

/**
 * Created by liaoruochen on 2017/4/14.
 * Description:
 */

public class CalendarLayout extends FrameLayout {

    private CalendarViewPager mWeekCalendar;
    private int mWeekCalendarHeight;
    private View mView;
    private float mDownX;
    private float mDownY;
    private boolean mIsClick;//是否点击的是ListView
    private boolean mIsSlide = false;
    //    Calendar状态相关
    public static final int TYPE_CLOSE = 0;
    public static final int TYPE_OPEN = 1;
    public int TYPE = TYPE_CLOSE;

    private VelocityTracker mVelocityTracker;//  主要用跟踪触摸屏事件的速率
    private CalendarViewPager mMonthCalendar;
    private int mMonthCalendarHeight;

    private int bottomViewTopHeight;//底部View距离layout顶部的距离
    private int mPointerId;
    private int mMaxVelocity;
    private int mMinVelocity;
    private ScrollerCompat mScroller;
    private int maxDistance;

    private static final Interpolator sInterpolator = new Interpolator() {
        @Override
        public float getInterpolation(float t) {
            t -= 1.0f;
            return t * t * t * t * t + 1.0f;
        }
    };
    private int mItemHeight=0;//item的高度

    public CalendarLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        final ViewConfiguration vc = ViewConfiguration.get(getContext());

        mMaxVelocity = vc.getScaledMaximumFlingVelocity();
        mMinVelocity = vc.getScaledMinimumFlingVelocity();
        mScroller = ScrollerCompat.create(getContext(), sInterpolator);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        measureChildren(widthMeasureSpec, heightMeasureSpec);
        Log.d("CalendarLayout", "onMeasure");

        if (mItemHeight==0){//
             mItemHeight = getItemHeight();
        }
        Log.d("CalendarLayout", "itemHeight:" + mItemHeight);

        mMonthCalendarHeight = mMonthCalendar.getMeasuredHeight();
        mWeekCalendarHeight = mWeekCalendar.getMeasuredHeight();

        maxDistance = mMonthCalendarHeight - mItemHeight;


        switch (TYPE) {
            case TYPE_CLOSE:
                bottomViewTopHeight = mItemHeight;
                break;
            case TYPE_OPEN:
                bottomViewTopHeight = mMonthCalendarHeight;
                break;
        }

        mView.measure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(heightMeasureSpec) - mItemHeight, MeasureSpec.EXACTLY));
    }


    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        //摆放ListView的位置
        mView.offsetTopAndBottom(bottomViewTopHeight);

        if (TYPE == TYPE_CLOSE) {
            mMonthCalendar.offsetTopAndBottom(-getItemMarginTop());
        }

    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {

        boolean isflag = false;

        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mDownX = ev.getX();
                mDownY = ev.getY();
                mIsClick = isClickRecyclerView(mView, ev);
                cancel();
                //返回其中一个触摸点
                mPointerId = ev.getPointerId(0);


                int top = mView.getTop();//返回值有两种情况，一是关闭状态，返回item高度，二是打开状态返回ViewPager高度


                if (top < mMonthCalendarHeight) {
                    TYPE = TYPE_CLOSE;
                } else {
                    TYPE = TYPE_OPEN;
                }
                break;

            case MotionEvent.ACTION_MOVE:
                float moveX = ev.getX();
                float moveY = ev.getY();

                float deltaX = moveX - mDownX;
                float deltaY = moveY - mDownY;

                if (Math.abs(deltaY) > 5 && Math.abs(deltaY) > Math.abs(deltaX)) {
                    isflag = true;//
                    if (mIsClick) {//是否触碰的是ListView
                        boolean isScroll = isScroll(mView);
                        if (deltaY > 0) {    //向下滑动
                            if (TYPE == TYPE_OPEN) {//日历是打开状态，而且是下拉listView，layout自己不处理，交给listView自己处理
                                return super.onInterceptTouchEvent(ev);
                            } else {//日历是关闭状态
                                if (isScroll) {//下拉listView，如果有内容可以下拉，那么交给ListView处理
                                    return super.onInterceptTouchEvent(ev);
                                }
                            }
                        } else {//向上滑动

                            if (TYPE == TYPE_CLOSE) {//日历是关闭状态，向上滑动交给listview自己处理
                                return super.onInterceptTouchEvent(ev);
                            } else {//日历打开状态

                                if (isScroll) {//如果有内容可以上拉,交给ListView处理
                                    // (情景：当listView滑到中间一半的时候，滑动日历控件，此时，日历控件是打开的，所以把事件交给ListView自己处理)
                                    return super.onInterceptTouchEvent(ev);
                                }
                            }
                        }
                    }

                }

                ///更新坐标
                mDownX = moveX;
                mDownY = moveY;
                break;

            case MotionEvent.ACTION_UP:

                break;
        }

        //当ListView自己处理不了的时候，isflag返回true，layout处理
        return isflag || super.onInterceptTouchEvent(ev) || mIsSlide;
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        processTouchEvent(event);
        return true;
    }


    private void processTouchEvent(MotionEvent event) {
        TYPE=TYPE_OPEN;
        toggleState();
        if (mVelocityTracker == null) {
            mVelocityTracker = VelocityTracker.obtain();
        }
        mVelocityTracker.addMovement(event);//监听触摸事件

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
//             从拦截事件过来，不会触发down事件
                break;
            case MotionEvent.ACTION_MOVE:
                if (mIsSlide) {
                    return;
                }
                float moveY = event.getY();
                float deltaY = moveY - mDownY;

                if (deltaY == 0) {
                    return;
                }
                mDownY = moveY;

                processY((int) deltaY);
                break;
            case MotionEvent.ACTION_UP:

                if (mIsSlide) {
                    cancel();
                    return;
                }

                //判断速度
                final int pointerId = mPointerId;

                mVelocityTracker.computeCurrentVelocity(1000, mMaxVelocity);
                float currentY = VelocityTrackerCompat.getYVelocity(mVelocityTracker, pointerId);

                if (Math.abs(currentY) > 2000) {
                    if (currentY > 0) {
                        open();
                    } else {
                        close();
                    }
                    cancel();
                    return;
                }

                int top = mView.getTop() - mMonthCalendarHeight;
                int maxd = maxDistance;

                if (Math.abs(top) < maxd / 2) {
                    open();
                } else {
                    close();
                }
                cancel();

                break;

            case MotionEvent.ACTION_CANCEL:
                cancel();
                break;
        }

    }

    /**
     * 关闭日历
     */
    private void close() {
        Log.d("CalendarLayout", "close");
        startScroll(mView.getTop(), mMonthCalendarHeight - maxDistance);
        TYPE=TYPE_CLOSE;
        toggleState();

//        mWeekCalendar.setVisibility(VISIBLE);
//        mMonthCalendar.setVisibility(GONE);
    }

    /**
     * 打开日历
     */
    private void open() {

        EventBus.getDefault().post(new MessageEvent("open"));
        Log.d("CalendarLayout", "open");
        startScroll(mView.getTop(), mMonthCalendarHeight);
        TYPE=TYPE_OPEN;
        toggleState();
//        mWeekCalendar.setVisibility(GONE);
//        mMonthCalendar.setVisibility(VISIBLE);
    }


    private  void toggleState(){
        mWeekCalendar.setVisibility(TYPE==TYPE_OPEN?INVISIBLE:VISIBLE);
        mMonthCalendar.setVisibility(TYPE==TYPE_OPEN?VISIBLE:INVISIBLE);
    }
    private void startScroll(int startY,int endY){
        float distance = endY - startY;
        float t = distance / maxDistance * 600;

        mScroller.startScroll(0, 0, 0, endY - startY, (int) Math.abs(t));
        postInvalidate();
    }



    int oldY = 0;
    @Override
    public void computeScroll() {
        super.computeScroll();
        bottomViewTopHeight = mView.getTop();
        if (mScroller.computeScrollOffset()) {
            mIsSlide = true;
            int cy = mScroller.getCurrY();
            int dy = cy - oldY;
            processY(dy);
            oldY = cy;
            postInvalidate();
        } else {
            oldY = 0;
            mIsSlide = false;
        }
    }

    private void cancel() {
        if (mVelocityTracker != null) {
            mVelocityTracker.recycle();
            mVelocityTracker = null;
        }
    }

    private void processY(int deltaY) {


        int itemMarginTop = getItemMarginTop();
        Log.d("CalendarLayout", "processY  itemMarginTop"+itemMarginTop);
        int itemHeight = getItemHeight();
        Log.d("CalendarLayout", "processY  itemHeight"+itemHeight);

        Log.d("CalendarLayout", "processY mMonthCalendar.getTop():" + mMonthCalendar.getTop());
        int dy1 = getAreaValue(mMonthCalendar.getTop(), deltaY, -itemMarginTop, 0);

        int dy2 = getAreaValue(mView.getTop() - mMonthCalendarHeight, deltaY, -(mMonthCalendarHeight - itemHeight), 0);


        if (dy1 != 0) {
            ViewCompat.offsetTopAndBottom(mMonthCalendar, dy1);
        }


        if (dy2 != 0) {
            ViewCompat.offsetTopAndBottom(mView, dy2);
        }


    }

    /**
     * ListView是否可以滚动
     *
     * @param view
     * @return
     */
    private boolean isScroll(View view) {
        if (view instanceof RecyclerView) {
            RecyclerView recyclerView = (RecyclerView) view;
            View childView = recyclerView.getChildAt(0);
            if (childView.getTop() != 0) {
                return true;
            } else {
                if (recyclerView.getChildLayoutPosition(childView) != 0) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * 获取View的引用
     */
    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        mMonthCalendar = (CalendarViewPager) getChildAt(0);

        mMonthCalendar.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
//                TODO:考虑WeekCalendar情况
                CalendarLayout.this.requestLayout();
            }
        });
        mWeekCalendar = (CalendarViewPager) getChildAt(1);
        mMonthCalendar.setVisibility(INVISIBLE);
        mWeekCalendar.setVisibility(VISIBLE);
        mView = getChildAt(2);
    }

    /**
     * 点击的是不是ListView
     *
     * @param view
     * @param ev
     * @return
     */
    private boolean isClickRecyclerView(View view, MotionEvent ev) {
        Rect rect = new Rect();
        view.getHitRect(rect);
        boolean isClick = rect.contains(((int) ev.getX()), ((int) ev.getY()));

        return isClick;
    }


    /**
     * 返回当前item的上下左右坐标
     *
     * @return
     */
    public int[] getCurrentSelectPosition() {
        int[] currentSelectPosition = mMonthCalendar.getCurrentSelectPosition();

        return currentSelectPosition;
    }

    /**
     * 返回Item的高度
     *
     * @return
     */
    public int getItemHeight() {
        int[] currentSelectPosition = mMonthCalendar.getCurrentSelectPosition();
        return currentSelectPosition[3] - currentSelectPosition[1];
    }

    public int getItemMarginTop() {
        int[] currentSelectPosition = getCurrentSelectPosition();
        return currentSelectPosition[1];
    }

    /**
     * @param top
     * @param dy       手指移动偏移量 上拉为正，下拉为负
     * @param minValue 允许移动到的最小值
     * @param maxValue 允许移动到的最大值
     * @return
     */
    public int getAreaValue(int top, int dy, int minValue, int maxValue) {

        //不允许继续往上拉
        if (top + dy < minValue) {
            return minValue - top;
        }
        //不允许继续往下拉
        if (top + dy > maxValue) {
            return maxValue - top;
        }
        //返回正常的偏移量
        return dy;
    }
}
