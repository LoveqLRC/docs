package com.example.administrator.calendardemo.ui;

import android.content.Context;
import android.graphics.Rect;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.administrator.calendardemo.R;
import com.example.administrator.calendardemo.demo.BaseEvent;
import com.example.administrator.calendardemo.demo.MonthEvent;
import com.example.administrator.calendardemo.demo.MonthJumpEvent;
import com.example.administrator.calendardemo.entity.CalendarBean;
import com.example.administrator.calendardemo.utils.CalendarUtil;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by liaoruochen on 2017/4/14.
 * Description:
 */

public class MonthView extends RecyclerView {

    private List<CalendarBean> mList = new ArrayList<>();
    public int mLastSelectPosition = -1;
    private final MonthViewAdapter mAdapter;

    public MonthView(Context context) {
        super(context);
        setLayoutManager(new GridLayoutManager(context, 7));
        mAdapter = new MonthViewAdapter();
        setAdapter(mAdapter);
    }


    class MonthViewAdapter extends RecyclerView.Adapter<MonthViewAdapter.ViewHolder> {

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_calendar, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            CalendarBean calendarBean = mList.get(position);
            holder.tv.setText(String.valueOf(calendarBean.day));
            holder.tv.setSelected(mLastSelectPosition == position);
//            如果不是当月设置其他颜色
            if (calendarBean.mothFlag != 0) {
                holder.tv.setTextColor(0xff9299a1);
            } else {
                holder.tv.setTextColor(0xffffffff);
            }
        }

        @Override
        public int getItemCount() {
            return mList == null ? 0 : mList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            private final TextView tv;

            public ViewHolder(View itemView) {
                super(itemView);
                tv = ((TextView) itemView.findViewById(R.id.text));
                tv.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int mCurrentSelectPosition = getLayoutPosition();
                        if (mLastSelectPosition != -1 && mLastSelectPosition != mCurrentSelectPosition) {

//                            getLayoutManager().findViewByPosition(mCurrentSelectPosition).setSelected(true);
//                            getLayoutManager().findViewByPosition(mLastSelectPosition).setSelected(false);
//                            notifyItemChanged(mLastSelectPosition);   //如果不调用的话，第一次刷新不了
//                            notifyItemChanged(mCurrentSelectPosition);   //如果不调用的话，第一次刷新不了
//                            mLastSelectPosition = mCurrentSelectPosition;

                            setSelectPosition(mCurrentSelectPosition);
                        }
                    }
                });
            }
        }
    }

    public void updateData(List<CalendarBean> list, boolean isToday) {
        mList.clear();
        mList.addAll(list);
        resetSelectPosition(isToday);
        getAdapter().notifyDataSetChanged();
    }

    /**
     * 更新默认选中天
     *
     * @param isToday
     */
    private void resetSelectPosition(boolean isToday) {
        if (isToday) {
            int[] ymd = CalendarUtil.getYMD(new Date());
            mLastSelectPosition = ymd[2] + mList.get(0).first - 1;
        } else {
            mLastSelectPosition = mList.get(0).first;

        }
    }

    /**
     * 当前选中的时间于实际的时间相差几个星期
     *
     * @return
     */
    public int getWeekInterval() {
        Log.d("MonthView", "mList.get(0).year:" + mList.get(mLastSelectPosition).year);
        Log.d("MonthView", "mList.get(0).moth:" + mList.get(mLastSelectPosition).moth);
        Log.d("MonthView", "mList.get(0).moth:" + mList.get(mLastSelectPosition).day);
        return CalendarUtil.getWeekInterval(mList.get(mLastSelectPosition).year, mList.get(mLastSelectPosition).moth, mList.get(mLastSelectPosition).day);
    }


    public int[] getSelectPosition() {
        Rect rect = new Rect();
//        try {
        getLayoutManager().findViewByPosition(mLastSelectPosition).getHitRect(rect);
//        }catch (Exception e){
//            e.printStackTrace();
//        }
        return new int[]{rect.left, rect.top, rect.right, rect.bottom};
    }


    public void setSelectPosition(int selectPosition) {
        CalendarBean bean = mList.get(selectPosition);
        if (bean.mothFlag == 0) {
            getLayoutManager().findViewByPosition(selectPosition).setSelected(true);
            getLayoutManager().findViewByPosition(mLastSelectPosition).setSelected(false);
            mAdapter.notifyItemChanged(mLastSelectPosition);   //如果不调用的话，第一次刷新不了
            mAdapter.notifyItemChanged(selectPosition);   //如果不调用的话，第一次刷新不了
//                            notifyDataSetChanged();
            mLastSelectPosition = selectPosition;

//            EventBus.getDefault().post(new MessageEvent("hello"));
            EventBus.getDefault().post(new MonthEvent(bean.year, bean.moth, bean.day,bean.week));


        } else {//  如果点击的不是当月，那么就跳转
            //下一个月是1
            //上一个月是-1
            EventBus.getDefault().post(new MonthJumpEvent(bean.mothFlag, bean.year, bean.moth, bean.day));
        }
    }

    public void updateSelectPoiAfterJump(BaseEvent event) {

        for (int i = 0; i < mList.size(); i++) {
            CalendarBean bean = mList.get(i);
            if (bean.year == event.year && bean.moth == event.month && bean.day == event.day) {
                mLastSelectPosition = i;
                mAdapter.notifyDataSetChanged();
                break;
            }
        }
    }


    public void updateSelectPoiAfterJump(CalendarBean event) {

        for (int i = 0; i < mList.size(); i++) {
            CalendarBean bean = mList.get(i);
            if (bean.year == event.year && bean.moth == event.moth && bean.day == event.day) {
                getLayoutManager().findViewByPosition(i).setSelected(true);
                getLayoutManager().findViewByPosition(mLastSelectPosition).setSelected(false);
                mAdapter.notifyItemChanged(mLastSelectPosition);   //如果不调用的话，第一次刷新不了
                mAdapter.notifyItemChanged(i);   //如果不调用的话，第一次刷新不了
//                            notifyDataSetChanged();
                mLastSelectPosition = i;
//                mAdapter.notifyDataSetChanged();
                break;
            }
        }
    }


    /**
     * 给定日期是否属于这个月中
     *
     * @param event
     * @return
     */
    public int dayInMonth(CalendarBean event) {
        for (int i = 0; i < mList.size(); i++) {
            CalendarBean bean = mList.get(i);
            if (bean.year == event.year && bean.moth == event.moth && bean.day == event.day) {
                return bean.mothFlag;
            }
        }
        return 0;
    }
}