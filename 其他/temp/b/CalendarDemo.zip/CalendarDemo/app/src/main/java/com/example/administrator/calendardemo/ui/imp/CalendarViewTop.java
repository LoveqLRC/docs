package com.example.administrator.calendardemo.ui.imp;

/**
 * Created by liaoruochen on 2017/4/17.
 * Description:
 */

public interface CalendarViewTop {
    int[] getCurrentSelectPosition();
}
