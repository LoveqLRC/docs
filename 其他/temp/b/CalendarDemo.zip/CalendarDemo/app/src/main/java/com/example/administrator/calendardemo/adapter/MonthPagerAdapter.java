package com.example.administrator.calendardemo.adapter;

import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;

import com.example.administrator.calendardemo.entity.CalendarBean;
import com.example.administrator.calendardemo.ui.CalendarViewPager;
import com.example.administrator.calendardemo.ui.MonthView;
import com.example.administrator.calendardemo.ui.imp.CalendarViewTop;
import com.example.administrator.calendardemo.utils.CalendarUtil;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by liaoruochen on 2017/4/14.
 * Description:
 */

public class MonthPagerAdapter extends PagerAdapter implements CalendarViewTop {
    private final CalendarViewPager vp;
    LinkedList<MonthView> cache = new LinkedList<>();
    SparseArray<MonthView> views = new SparseArray<>();
    int[] ymd;
    int interval=0;
//    int selectPosi=0;

    public MonthPagerAdapter(CalendarViewPager parent) {
        ymd = CalendarUtil.getYMD(new Date());
        this.vp = parent;
    }

    @Override
    public int getCount() {
//        return Integer.MAX_VALUE;
        return 200;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        MonthView view;
        if (!cache.isEmpty()) {
            view = cache.removeFirst();
        } else {
            view = new MonthView(container.getContext());
        }

        view.setId(position);//为了获取当前view

        Log.d("MonthPagerAdapter", "instantiateItem interval:" + interval);
//        List<CalendarBean> dayList = CalendarUtil.getMonthOfDayList(ymd[0], ymd[1] + position - Integer.MAX_VALUE / 2+interval);
        List<CalendarBean> dayList = CalendarUtil.getMonthOfDayList(ymd[0], ymd[1] + position - getCount()/2+interval);
//        view.updateData(dayList, position +interval== Integer.MAX_VALUE / 2);
        view.updateData(dayList, position +interval== getCount()/2);

        container.addView(view);
        views.put(position, view);
        return view;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
        cache.addLast((MonthView) object);
        views.remove(position);
    }


    @Override
    public int[] getCurrentSelectPosition() {
        MonthView view = views.get(vp.getCurrentItem());
        return view.getSelectPosition();
    }



    /**
     * 使   notifyDataSetChanged();生效
     * @param object
     * @return
     */
    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE ;
    }

    public void updateMonthInterval(int monthInterval, int selectPosi){
//        interval=monthInterval;
//        this.selectPosi=selectPosi;
////        views.clear();
//
//        notifyDataSetChanged();
////        vp.setCurrentItem(vp.getCurrentItem()+monthInterval,false);
    }
}
