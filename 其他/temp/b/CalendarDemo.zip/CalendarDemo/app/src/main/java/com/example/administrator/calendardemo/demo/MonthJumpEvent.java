package com.example.administrator.calendardemo.demo;

/**
 * Created by liaoruochen on 2017/4/18.
 * Description:
 */

public class MonthJumpEvent extends BaseEvent {
    public int upOrNext;

    public MonthJumpEvent(int upOrNext, int year, int month, int day) {
        this.upOrNext = upOrNext;
        this.year = year;
        this.month = month;
        this.day = day;
    }
}
