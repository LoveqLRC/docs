package com.example.administrator.calendardemo.demo;

/**
 * Created by liaoruochen on 2017/4/18.
 * Description:
 */

public class WeekEvent extends BaseEvent {


    public WeekEvent(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }
}
