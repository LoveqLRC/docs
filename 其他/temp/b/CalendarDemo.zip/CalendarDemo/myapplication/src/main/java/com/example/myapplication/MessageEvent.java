package com.example.myapplication;

/**
 * Created by liaoruochen on 2017/4/17.
 * Description:
 */

public class MessageEvent {
    private String mMsg;

    public MessageEvent(String msg) {
        mMsg = msg;
    }

    public String getMsg() {
        return mMsg;
    }
}
